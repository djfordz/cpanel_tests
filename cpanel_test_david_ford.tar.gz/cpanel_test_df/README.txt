Hello,

I hope you find my module and scripts well written.

Perl is not a language I have been using long, but I think you will notice I have used some advanced programming concepts based on my core programming knowledge.

I apologize if my test file is not on par as I am not used to writing unit tests, however I would easily pick this up with a few days if I had someone go over with me.

I look forward to your response.

Best Regards,

David Ford
djfordz@gmail.com
